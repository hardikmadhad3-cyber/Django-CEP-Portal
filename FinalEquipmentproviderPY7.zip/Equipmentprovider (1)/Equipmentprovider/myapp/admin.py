from django.contrib import admin
from .models import *
# Register your models here.


class showUsers(admin.ModelAdmin):
    list_display = ['id', 'name', 'email', 'password', 'phone_number', 'userType']

admin.site.register(Login,showUsers)



class showStates(admin.ModelAdmin):
    list_display = ['State_name']

admin.site.register(State,showStates)



class showCity(admin.ModelAdmin):
    list_display = ['State_id', 'City_name']

admin.site.register(City,showCity)



class showArea(admin.ModelAdmin):
    list_display = ['Area_name', 'City_id', 'STATE']

admin.site.register(Area,showArea)



class showUserDetails(admin.ModelAdmin):
    list_display = ['userid', 'dob', 'address', 'customer_photos', 'area', 'city', 'state']

admin.site.register(UserDetail, showUserDetails)



class showProductCategory(admin.ModelAdmin):
    list_display = ['cateName']

admin.site.register(ProductCategory, showProductCategory)



class showProduct(admin.ModelAdmin):
    list_display = ['name', 'Cate', 'desc', 'price']

admin.site.register(Product, showProduct)



class showProductImage(admin.ModelAdmin):
    list_display = ['product', 'productPhoto']

admin.site.register(ProductImage, showProductImage)



class showStores(admin.ModelAdmin):
    list_display = ['name', 'verified', 'is_active']

admin.site.register(Store, showStores)


class showStoreDetails(admin.ModelAdmin):
    list_display = ['store', 'contact', 'email', 'address', 'storelogo', 'description']
admin.site.register(StoreDetail, showStoreDetails)



class MachineryAdmin(admin.ModelAdmin):
    list_display = ('name', 'store', 'available_for_rent', 'rental_duration', 'is_operational', 'production_year', 'timestamp')
    list_filter = ('store', 'available_for_rent', 'rental_duration', 'is_operational')
    search_fields = ('name', 'description')
    date_hierarchy = 'timestamp'

admin.site.register(Machinery,MachineryAdmin)


class MachineCategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
admin.site.register(MachineCategory,MachineCategoryAdmin)


class showMachineryImage(admin.ModelAdmin):
    list_display = ['machinery', 'machinePhoto']

admin.site.register(MachineryImage, showMachineryImage)


class showBooking(admin.ModelAdmin):
    list_display = ['user', 'machinery', 'payment_method', 'status', 'start_date', 'end_date', 'total_price']

admin.site.register(Booking, showBooking)



class showCardDetails(admin.ModelAdmin):
    list_display = ['name', 'card_number', 'card_cvv', 'exp_date', 'card_balance']

admin.site.register(CardDetail, showCardDetails)




class showCart(admin.ModelAdmin):
    list_display = ['user', 'product', 'Price', 'Quantity', 'Order_id', 'Order_status', 'timeStamp']

admin.site.register(productCart, showCart)


class showOrders(admin.ModelAdmin):
    list_display = ['id', 'user', 'totalAmount', 'Address', 'order_status', 'Payment_status', 'Date_time']

admin.site.register(product_order, showOrders)


class showPayment(admin.ModelAdmin):
    list_display = ['booking', 'amount', 'transaction_id', 'payment_date_time', 'payment_method', 'payment_status']

admin.site.register(payment, showPayment)



class showEcommercePayment(admin.ModelAdmin):
    list_display = ['user', 'order_id', 'amount', 'payment_method', 'transaction_id', 'payment_status', 'timestamp']

admin.site.register(ecommercePayment, showEcommercePayment)



class showContacts(admin.ModelAdmin):
    list_display = ['name', 'email', 'phone', 'message', 'timestamp']

admin.site.register(Contact, showContacts)


class showFeedbacks(admin.ModelAdmin):
    list_display = ['user', 'product', 'ratings', 'comment']

admin.site.register(Feedback, showFeedbacks)
