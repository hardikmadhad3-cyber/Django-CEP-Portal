from django.shortcuts import render,redirect
from .models import *
import datetime
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib import messages
from datetime import datetime

# Create your views here.

def checksession(request):
    try:
        uid = request.session['login_id']
        userdata = Login.objects.get(id=uid)
        try:
            profiledata = UserDetail.objects.get(userid=uid)
        except UserDetail.DoesNotExist:
            profiledata = None

        store = False
        if userdata.userType == "store":
            store = True

        context = {
            'userdata': userdata,
            'profiledata': profiledata,
            'store': store
        }

        return context
    except:
        pass

def calculate_total_price(start_date, end_date, rent_perday):
    one_day = 1
    days = (end_date - start_date).days + 1
    return rent_perday * days


def is_booking_overlapping(machinery, start_date, end_date):
    existing_bookings = Booking.objects.filter(
        machinery=machinery,
        start_date__lte=end_date,
        end_date__gte=start_date
    )
    return existing_bookings.exists()

def indexpage(request):
    context = checksession(request)
    return render(request, "index.html", context)


def signuppage(request):
    return render(request, "signup.html")


def register(request):
    try:
        if request.method == "POST":
            name = request.POST.get("name")
            email = request.POST.get("email")
            phone = request.POST.get("phone")
            password1 = request.POST.get("password1")
            password2 = request.POST.get("password2")

            if Login.objects.filter(email=email).exists():
                messages.error(request, "Email already exists. Please choose a different email.")
                return redirect(indexpage)

            if password1 == password2:
                registerdata = Login(name=name, email=email, phone_number=phone, password=password1)
                registerdata.save()
                messages.info(request, "Registerd Successfully now you can login.")
                return redirect(loginpage)
            else:
                messages.error(request, "Passwords are nor same")

    except:
        pass

    return render(request, "signup.html")


def storeregisterpage(request):
    return render(request, "storeregister.html")

def registerstore(request):
    if request.method == 'POST':
        uname = request.POST.get("name")
        uemail = request.POST.get("email")
        ucontact = request.POST.get("contact")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")
        storename = request.POST.get("storename")

        if password1 == password2:

            userdata = Login(name=uname, email=uemail, phone_number=ucontact, password=password1, userType="store")
            userdata.save()

            storedata = Store(user=Login(id=userdata.id), name=storename, verified=False, is_active=True)
            storedata.save()

            messages.success(request, 'Data Inserted Successfully.')
            return redirect(loginpage)

        else:
            messages.error(request, 'Passwords are not same')
            redirect(storeregisterpage)

    else:
        messages.error(request, 'error occured')
        redirect(indexpage)

    return render(request, "index.html")


def loginpage(request):
    return render(request, "login.html")

def logincheck(request):
    if request.method == "POST":
        uemail = request.POST.get("email")
        upwd = request.POST.get("password")
        print(uemail)
        print(upwd)
        try:
            logindata = Login.objects.get(email=uemail, password=upwd)
            request.session['login_id'] = logindata.id
            request.session.save()

        except Login.DoesNotExist:
            logindata = None


        if logindata is not None:
            messages.success(request, "Login Successfull !!")
            print(logindata)
            return redirect(indexpage)

        else:
            messages.error(request, "Invalid Details")
            return redirect(loginpage)

    return render(request, 'login.html')



def changepwdpage(request):
    context = checksession(request)
    return render(request, "changepassword.html", context)


def changepwd(request):
    context = checksession(request)
    userdata = context.get("userdata")
    try:
        pwd = userdata.password
        print(pwd)
        if request.method == "POST":
            oldpwd = request.POST.get("oldpwd")
            print(oldpwd)
            newpwd = request.POST.get("newpwd")
            confirmpwd = request.POST.get("confirmpwd")

            if oldpwd == pwd:
                if newpwd == confirmpwd:
                    userdata.password = newpwd
                    userdata.save()
                    messages.success(request, 'Password Updated Successfully.')
                    del request.session['login_id']
                    return redirect(loginpage)
                else:
                    messages.error(request, "New Password and confirm not same")
                    return redirect(changepwdpage)
            else:
                messages.error(request, "Invalid Old Password")
                return redirect(changepwdpage)

    except userdata.DoesNotExist:
        messages.error(request, 'This account does not exist.')
        return redirect(indexpage)
    return render(request, "index.html", context)




def loguout(request):
    try:
        del request.session['login_id']
        messages.info(request, "Logout Successfully!")
    except:
        pass

    return render(request, "index.html")



def forgotpasswordpage(request):
    context = checksession(request)
    return render(request, "forgotpassword.html", context)


def forgotpassword(request):
    if request.method == 'POST':
        username = request.POST.get('email')

        try:
            user = Login.objects.get(email=username)

        except Login.DoesNotExist:
            user = None

        if user is not None:
            #################### Password Generation ##########################
            import random
            letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                       't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
                       'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
            numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

            nr_letters = 6
            nr_symbols = 1
            nr_numbers = 3
            password_list = []

            for char in range(1, nr_letters + 1):
                password_list.append(random.choice(letters))

            for char in range(1, nr_symbols + 1):
                password_list += random.choice(symbols)

            for char in range(1, nr_numbers + 1):
                password_list += random.choice(numbers)

            print(password_list)
            random.shuffle(password_list)
            print(password_list)

            password = ""  #we will get final password in this var.
            for char in password_list:
                password += char

            ##############################################################


            msg = "hello here it is your new password  "+password   #this variable will be passed as message in mail

            ############ code for sending mail ########################

            from django.core.mail import send_mail

            send_mail(
                'Your New Password',
                msg,
                'rahulinfolabz@gmail.com',
                [username],
                fail_silently=False,
            )

            #now update the password in model
            cuser = Login.objects.get(email=username)
            cuser.password = password
            cuser.save(update_fields=['password'])

            print('Mail sent')
            messages.info(request, 'mail is sent successfully to your registered email')
            return redirect(indexpage)
        else:
            messages.info(request, 'This account does not exist')
    return redirect(indexpage)


def userprofile(request):
    context = checksession(request)
    print(context)
    return render(request, "userprofile.html", context)

def aboutpage(request):
    context = checksession(request)
    print(context)
    return render(request, "about.html", context)



def contactpage(request):
    context = checksession(request)
    print(context)
    return render(request, "contact.html", context)


def contactus(request):
    context = checksession(request)
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        message = request.POST.get("message")

        insert = Contact(name=name, email=email, phone=phone, message=message, timestamp="")
        insert.save()

        messages.info(request, "Our team will contact with you within a 24 hours")
        return  redirect(indexpage)

    return render(request, 'index.html', context)




def completeprofilepage(request):
    context = checksession(request)
    try:
        statedetail = State.objects.all()
        citydetail = City.objects.all()
        areadetail = Area.objects.all()

        context.update({'statedetail': statedetail, 'citydetail': citydetail, 'areadetail': areadetail,})
        return render(request, 'completeprofile.html', context)
    except:
        pass

    return render(request, "completeprofile.html", context)


def completestoreprofilepage(request):
    context = checksession(request)
    try:
        statedetail = State.objects.all()
        citydetail = City.objects.all()
        areadetail = Area.objects.all()

        context.update({'statedetail': statedetail, 'citydetail': citydetail, 'areadetail': areadetail, })
        return render(request, "completestoreprofile.html", context)
    except:
        pass
    return render(request, "completestoreprofile.html", context)


def completestoreprofile(request):
    uid = request.session['login_id']
    if request.method == 'POST':
        uaddress = request.POST.get("address")
        udob = request.POST.get("dob")
        file = request.FILES['profile']
        uarea = request.POST.get("areaname")
        ucity = request.POST.get("cityname")
        ustate = request.POST.get("statename")
        storeemail = request.POST.get("storeemail")
        storecontact = request.POST.get("storecontact")
        logo = request.FILES['logo']
        storeaddress = request.POST.get("address")
        description = request.POST.get("description")

        userdata = UserDetail(userid=Login(id=uid), dob=udob, address=uaddress, profile=file, area=Area(id=uarea), city=City(id=ucity), state=State(id=ustate))
        userdata.save()

        storedata = Store.objects.get(user=uid)
        storeid = storedata.id

        storedetail = StoreDetail(store=Store(id=storeid), contact=storecontact, email=storeemail,address=storeaddress, logo=logo, description=description)
        storedetail.save()

        messages.success(request, 'Data Inserted Successfully.')
        return redirect(indexpage)
    else:
        messages.error(request, 'error occured')

    return render(request, "index.html")


def storeprofile(request):
    context = checksession(request)
    uid = request.session["login_id"]
    storedata = Store.objects.get(user=Login(id=uid))

    # Use filter instead of get to handle MultipleObjectsReturned
    storedetails = StoreDetail.objects.filter(store=storedata)

    # You can choose to take the first result or iterate over all results
    if storedetails.exists():
        storedetail = storedetails.first()  # Choose the first result
        context.update({"storedata": storedata, "storedetail": storedetail})
    else:
        context.update({"storedata": storedata, "storedetail": None})

    return render(request, "storeprofile.html", context)

def completeprofile(request):
    uid = request.session['login_id']
    if request.method == 'POST':
        uaddress = request.POST.get("address")
        udob = request.POST.get("dob")
        file = request.FILES['profile']
        uarea = request.POST.get("areaname")
        ucity = request.POST.get("cityname")
        ustate = request.POST.get("statename")
        userdata = UserDetail(userid=Login(id=uid), dob=udob, address=uaddress, profile=file, area=Area(id=uarea), city=City(id=ucity), state=State(id=ustate))
        userdata.save()
        messages.success(request, 'Data Inserted Successfully.')
        return redirect(indexpage)
    else:
        messages.error(request, 'error occured')

    return render(request, "index.html")


def edituserprofile(request):
    context = checksession(request)
    try:
        statedetail = State.objects.all()
        citydetail = City.objects.all()
        areadetail = Area.objects.all()

        context.update({'statedetail': statedetail,'citydetail': citydetail,'areadetail': areadetail,})

    except:
        pass

    return render(request, 'editprofile.html', context)


def updateprofile(request):

    context = checksession(request)
    uid = request.session['login_id']
    userdata = Login.objects.get(id=uid)
    profiledata = UserDetail.objects.get(userid=uid)
    if request.method == "POST":

        if 'update' in request.POST:
            uname = request.POST.get("name")
            uemail = request.POST.get("email")
            uphone = request.POST.get("phone")
            uaddress = request.POST.get("address")
            udob = request.POST.get("dob")

            userdata.name = uname
            userdata.phone_number = uphone
            userdata.email = uemail
            profiledata.dob = udob
            profiledata.address = uaddress

            if 'profile' in request.FILES:
                profile = request.FILES["profile"]
                profiledata.profile = profile

                userdata.save()
                profiledata.save()

                messages.success(request, 'Your profile has been updated successfully.')
                return redirect(userprofile)


            else:
                profiledata.profile = profiledata.profile
                userdata.save()
                profiledata.save()

                messages.success(request, 'Your profile has been updated successfully.')
                return redirect(userprofile)

        elif 'cancel' in request.POST:
            if context.get("store"):
                return redirect(storeprofile)
            else:
                return redirect(userprofile)

    return render(request, "index.html", context)



def editstoreprofilepage(request):
    context = checksession(request)
    uid = request.session["login_id"]
    try:
        storedata = Store.objects.get(user=Login(id=uid))

        storedetails = StoreDetail.objects.filter(store=storedata)

        if storedetails.exists():
            storedetail = storedetails.first()  # Choose the first result
            context.update({"storedata": storedata, "storedetail": storedetail})
        else:
            context.update({"storedata": storedata, "storedetail": None})

        return render(request, 'editstoreprofile.html', context)

    except:
        pass

    return render(request, 'editstoreprofile.html', context)




def updatestoreprofile(request):
    context = checksession(request)
    uid = request.session['login_id']
    userdata = Login.objects.get(id=uid)
    profiledata = UserDetail.objects.get(userid=uid)
    # try:
    storedata = Store.objects.get(user=Login(id=uid))
    storedetails = StoreDetail.objects.get(store=Store(id=storedata.id))

    if request.method == "POST":
        if 'update' in request.POST:
            uname = request.POST.get("name")
            uemail = request.POST.get("email")
            uphone = request.POST.get("phone")
            uaddress = request.POST.get("address")
            udob = request.POST.get("dob")

            storename = request.POST.get("storename")
            storeemail = request.POST.get("storeemail")
            storephone = request.POST.get("storephone")
            storeaddreess = request.POST.get("storeaddreess")
            desc = request.POST.get("desc")

            userdata.name = uname
            userdata.phone_number = uphone
            userdata.email = uemail

            profiledata.dob = udob
            profiledata.address = uaddress

            storedata.name = storename

            storedetails.email = storeemail
            storedetails.contact = storephone
            storedetails.address = storeaddreess
            storedetails.description = desc

            if "storelogo" in request.FILES:
                logo = request.FILES["storelogo"]
                storedetails.logo = logo
                storedetails.save()
                storedetails.save()

            else:
                storedetails.logo = storedetails.logo
                storedetails.save()
                storedata.save()


            if 'profile' in request.FILES:
                profile = request.FILES["profile"]
                profiledata.profile = profile

                userdata.save()
                profiledata.save()
            else:
                profiledata.profile = profiledata.profile
                userdata.save()
                profiledata.save()
            storedetails.save()
            storedata.save()

            messages.success(request, 'Your profile has been updated successfully.')
            return redirect(storeprofile)

        elif 'cancel' in request.POST:
            if context.get("store"):
                return redirect(storeprofile)
            else:
                return redirect(userprofile)
    #
    # except:
    #     pass

    return render(request, "index.html", context)




def ecommercepage(request):
    context = checksession(request)
    try:
        productsdata = Product.objects.all()
        combineddata = []
        # Iterate through each property data
        for products in productsdata:
            # Fetch images for the current property
            productimage = ProductImage.objects.filter(product=products.id)

            # Check if there are any images for the property
            if productimage.exists():
                # Include only the first image in the combined data
                first = productimage.first()
                combineddata.append((products, first))
            else:
                # If no images are found, include the property data with None for the image
                combineddata.append((products, None))

        context.update({"combineddata": combineddata})
        return render(request, "ecommerce.html", context)

    except:
        pass

    return render(request, "ecommerce.html")


def productdetails(request,id):
    context = checksession(request)
    try:
        context = checksession(request)
        uid = request.session["login_id"]
        profiledata = UserDetail.objects.get(userid=uid)

    except UserDetail.DoesNotExist:
        profiledata = None

    if profiledata == None:
        messages.info(request, "please complete your profile then you can book")

    try:

        productdata = Product.objects.get(id=id)
        images = ProductImage.objects.filter(product=id)
        context.update({"productdata": productdata, "imagesdata": images})

    except:
        pass

    return render(request, "ecommerce-single.html", context)


def add_to_cart(request):
    uid = request.session["login_id"]
    if request.method == 'POST':

        pid = request.POST.get("pid")
        pprice = request.POST.get("pprice")
        quantity = request.POST.get("quantity")
        total = int(pprice)*int(quantity)

        existing_item = productCart.objects.filter(user=Login(id=uid), product=pid, Order_status=0).first()

        if existing_item:
            existing_item.Quantity += int(quantity)
            existing_item.save()
            messages.info(request,"Product added in cart successfully !!")
        else:
            productdata = productCart(user=Login(id=uid), product=Product(id=pid), Price=total,Quantity=quantity,Order_id=0, Order_status=0, timeStamp="")
            productdata.save()
            messages.info(request,"Product added in cart successfully !!")

        return redirect(ecommercepage)

    else:
        # If it's not a POST request, redirect to the product page
        return redirect(productdetails, id=id)


def placeorder(request):
    uid = request.session.get("login_id")
    context = checksession(request)

    # Fetch the user's cart items
    cart_items = productCart.objects.filter(user=Login(id=uid), Order_status=0)

    print(cart_items)

    # Calculate total amount
    total_amount = sum(item.Price for item in cart_items)

    print(total_amount)

    if request.method == "POST":
        address = request.POST.get("address")
        print(address)
        payment_method = request.POST.get("payment_method")  # Assuming a field for payment method
        print(payment_method)

        if payment_method == "offline":
            # Create an order
            order = product_order(
                totalAmount=total_amount,
                user=Login(id=uid),
                Address=address,
                order_status='Placed',
                Payment_status='pending',
                Date_time=""  # Assuming initial payment status is pending
            )
            order.save()

            order_id = order.id

            # Update cart items with the order details
            for item in cart_items:
                item.Order_id = order.id
                item.Order_status = 1  # Update order status in the cart item
                item.save()

            insertpayment = ecommercePayment(user=Login(id=uid), order_id=product_order(id=order_id),
                                             amount=total_amount, transaction_id="None", timestamp="",
                                             payment_method="offline", payment_status="complete")
            insertpayment.save()

            messages.success(request, 'Order placed successfully!')
            # return redirect(order_details, order_id=order.id)

            return redirect(indexpage)

        elif payment_method == "online":
            cardNumber = request.POST.get('cardNumber')
            cvv = request.POST.get('cvv')
            expiryDate = request.POST.get('expiryDate')

            carddata = CardDetail.objects.first()
            number = carddata.card_number
            balance = carddata.card_balance
            expdate = carddata.exp_date
            ccvv = carddata.card_cvv

            if cardNumber == number and int(total_amount) < balance and expiryDate == expdate and cvv == ccvv:

                order = product_order(
                    totalAmount=total_amount,
                    user=Login(id=uid),
                    Address=address,
                    order_status='Placed',
                    Payment_status='complete',
                    Date_time=""
                )
                order.save()
                order_id = order.id
                # Update cart items with the order details
                for item in cart_items:
                    item.Order_id = order.id
                    item.Order_status = 1  # Update order status in the cart item
                    item.save()

                trans = generate_transaction_id()
                #
                insertpayment = ecommercePayment(user=Login(id=uid),order_id=product_order(id=order_id), amount=total_amount, transaction_id=trans, timestamp="", payment_method="online", payment_status="complete")
                insertpayment.save()

                messages.success(request, 'Payment is Done Order placed successfully!')
                # return redirect(indexpage)
            else:
                messages.error(request, "Tansaction failed invalid Details")
                return redirect(ecommercepage)

        else:
            messages.error(request,"Some Error Occurs")
            return redirect(indexpage)

    return render(request, "index.html", context)


def usercart(request):
    context = checksession(request)
    uid = request.session["login_id"]
    cartdata = productCart.objects.filter(user=Login(id=uid), Order_status=0)
    if cartdata.exists():
        display = True
    else:
        display = False
    context.update({"cartdata": cartdata,"display":display})
    print(cartdata)
    return render(request, "cart.html", context)


def addmachinespage(request):
    context = checksession(request)
    profile = context.get("profiledata")

    try:
        if profile == None:
            messages.info(request, "please complete your profile.")
            return redirect(completestoreprofilepage)
    except:
        pass
    category = MachineCategory.objects.all()
    context.update({"category": category})
    return render(request, "addmachines.html", context)

def addmachines(request):
    context = checksession(request)
    uid = request.session["login_id"]
    try:
        if request.method == "POST":
            name = request.POST.get("name")
            baseprice = request.POST.get("baseprice")
            year = request.POST.get("year")
            desc = request.POST.get("desc")
            category = request.POST.get("category")

            storedata = Store.objects.get(user=Login(id=uid))
            storeid = storedata.id

            machinedata = Machinery(category=MachineCategory(id=category), name=name,description=desc, price=baseprice, store=Store(id=storeid),available_for_rent=True, rental_duration="daily", is_operational=True, production_year=year,timestamp ="")
            machinedata .save()

            messages.info(request, "Machine Data Added Successfully.")
            return redirect(indexpage)
        else:
            messages.error(request, "Some Error Occurs")

    except:
        pass
    return render(request, "index.html", context)


def addmachinesimagespage(request):
    context = checksession(request)
    uid = request.session["login_id"]
    profile = context.get("profiledata")
    try:
        if profile == None:
            messages.info(request, "please complete your profile.")
            return redirect(completestoreprofilepage)
    except:
        pass


    try:
        storedata = Store.objects.get(user=Login(id=uid))
        storeid = storedata.id

        machines = Machinery.objects.filter(store=storeid)
        context.update({"machines": machines})

    except Store.DoesNotExist:
        store = None
        machines = None
        context.update({"machines": machines, "store": store})
    return render(request, "addmachineimages.html", context)


def addmachineimages(request):
    context = checksession(request)
    try:
        if request.method == "POST":
            machine = request.POST.get("machine")
            images = request.FILES["machineimage"]

            machinedata = MachineryImage(machinery=Machinery(id=machine), image= images)
            machinedata.save()

            messages.info(request, "Machine Images Added Successfully.")
            return redirect(indexpage)
        else:
            messages.error(request, "Some Error Occurs")

    except:
        pass

    return render(request, "index.html", context)


def viewmachines(request):
    context = checksession(request)
    uid = request.session["login_id"]
    try:
        current_store = Store.objects.get(user=uid)
        machines = Machinery.objects.filter(store=current_store)
        context.update({"machines": machines})
    except Store.DoesNotExist:
        messages.info(request, "Please complete profile then you can perform task")
        machines = None
        current_store = None
        context.update({"machines": machines, "current_store":current_store})
    return render(request, "viewmachines.html", context)


def viewbookings(request):
    context = checksession(request)
    uid = request.session["login_id"]
    try:
        current_store = Store.objects.get(user=uid)
        machines = Machinery.objects.filter(store=current_store)
        bookings = Booking.objects.filter(machinery__in=machines)

    except Store.DoesNotExist:
        messages.info(request, "Please complete profile then you can perform task")

    context.update({"bookings": bookings})
    return render(request, "viewbookings.html", context)


def viewmachineimages(request):
    context = checksession(request)
    uid = request.session["login_id"]
    storedata = Store.objects.get(user=uid)
    storeid = storedata.id
    machines_with_images = Machinery.objects.filter(store=storeid, machineryimage__isnull=False).distinct()

    context.update({"machines_with_images": machines_with_images})
    return render(request, "viewmachineimages.html", context)


def usermachines(request):
    context = checksession(request)
    try:
        machines_with_images = Machinery.objects.filter(machineryimage__isnull=False, store__verified=True, store__is_active=True).distinct()
        context.update({"machines_with_images": machines_with_images})
        return render(request, "usermachines.html", context)
    except:
        pass
    return render(request, "index.html", context)

def machines(request):
    try:
        machines_with_images = Machinery.objects.filter(machineryimage__isnull=False, store__verified=True, store__is_active=True).distinct()
        context= {"machines_with_images": machines_with_images}
        return render(request, "machines.html", context)
    except:
        pass
    return render(request, "index.html", context)


def machineDetails(request, id):
    context = checksession(request)
    uid = request.session["login_id"]
    try:
        machinedata = Machinery.objects.get(id=id)
        images = MachineryImage.objects.filter(machinery=id)
        context.update({"machinedata": machinedata, "imagesdata": images})

    except:
        pass
    return render(request, "machinesdetails.html", context)


def machinecategory(request):
    context = checksession(request)
    return render(request, "usermachinecategory.html", context)


import uuid
def generate_transaction_id():
    return str(uuid.uuid4())


def bookmachine(request, id):
    context = checksession(request)
    uid = request.session["login_id"]
    if request.method == 'POST':
        user = uid
        machinery = Machinery.objects.get(id=id)
        payment_method = request.POST.get('payment')
        start_date = datetime.strptime(request.POST.get('bf'), '%Y-%m-%d').date()
        end_date = datetime.strptime(request.POST.get('bt'), '%Y-%m-%d').date()
        total_price = calculate_total_price(start_date, end_date, machinery.price)

        cardNumber = request.POST.get('cardNumber')
        cvv = request.POST.get('cvv')
        expiryDate = request.POST.get('expiryDate')


        if is_booking_overlapping(machinery, start_date, end_date):
            messages.info(request, 'Selected booking dates are already booked please select another one.')
            return redirect(usermachines)


        if payment_method == "offline":
            insertbooking = Booking(user=Login(id=user), machinery=machinery,payment_method=payment_method,status='confirmed',start_date=start_date,end_date=end_date,total_price=total_price)
            insertbooking.save()

            bid = insertbooking.id

            insertpayment = payment(user=Login(id=user), booking=Booking(id=bid), amount=total_price, transaction_id="None",
                                    payment_date_time="",payment_method="offline", payment_status="complete")
            insertpayment.save()

            messages.success(request, 'Booking successful!')

            return redirect(indexpage)

        elif payment_method == "online":
            carddata = CardDetail.objects.first()
            number = carddata.card_number
            balance = carddata.card_balance
            expdate = carddata.exp_date
            ccvv = carddata.card_cvv

            if cardNumber == number and int(total_price) < balance and expiryDate == expdate and cvv == ccvv:

                insertbooking = Booking(user=Login(id=user), machinery=machinery, payment_method=payment_method,
                                        status='pending', start_date=start_date, end_date=end_date,
                                        total_price=total_price)
                insertbooking.save()
                bid = insertbooking.id

                trans = generate_transaction_id()

                insertpayment = payment(user=Login(id=user), booking=Booking(id=bid), amount=total_price, transaction_id=trans, payment_date_time="", payment_method="online", payment_status="complete")
                insertpayment.save()

                messages.success(request, 'Payment is Done Booked successfully!!')
                return redirect(indexpage)

            else:
                messages.error(request, "Tansaction Failed Invalid Details")
                return redirect(usermachines)
        else:
            messages.error(request,"Some Error Occurs")
            return redirect(indexpage)

    return render(request,"index.html", context)


def userbookings(request):
    try:
        context = checksession(request)
        uid = request.session['login_id']
        userbookings = Booking.objects.filter(user=uid)
        context.update({"bookings": userbookings})

    except Booking.DoesNotExist:
        messages.error(request, "No Bookings Had Done")

    return render(request, "viewuserbookings.html", context)


def userpayments(request):
    context = checksession(request)
    try:
        uid = request.session['login_id']
        userpayment = payment.objects.filter(user=uid)
        context.update({"payments": userpayment})

    except Exception as e:
        messages.error(request,f"{e}")

    return render(request, "viewuserpayments.html", context)


def myorders(request):
    context = checksession(request)
    # Retrieve orders for the current logged-in user
    user_id = request.session.get('login_id')
    user = Login.objects.get(id=user_id)

    orders = product_order.objects.filter(user=user)
    if orders.exists():
        display = True
    else:
        display = False
    payment = ecommercePayment.objects.filter(user=user)

    print(orders)
    context.update({
        'orders': orders,
        'payment': payment,
        'display':display
    })

    return render(request, 'myorders.html', context)



def viewdetails(request, id):
    # Retrieve orders for the current logged-in user
    context = checksession(request)
    user_id = request.session.get('login_id')
    order = product_order.objects.get(id=id,user=user_id)
    orderid = order.id
    products = productCart.objects.filter(user=user_id, Order_id=orderid, Order_status=1)

    context.update({
        'orderitems': products
    })
    return render(request, 'orderdetails.html', context)

def profuctfeedback(request):
    context = checksession(request)
    user_id = request.session.get('login_id')
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        ratings = request.POST.get('ratings')
        feedback_message = request.POST.get('feedback_message')

        if Feedback.objects.filter(user=Login(id=user_id), product=Product(id=product_id)):
            messages.error(request, "Feedback all ready exist")
            return redirect(ecommercepage)

        Feedback.objects.create(
            user=Login(id=user_id),
            product_id=product_id,
            ratings=ratings,
            comment=feedback_message
        )

        messages.success(request, "feedback submitted successful")
        return redirect(productdetails, id=product_id)

    return render(request, "index.html",context)


def ecommerceItems(request):
    try:
        productsdata = Product.objects.all()
        combineddata = []
        # Iterate through each property data
        for products in productsdata:
            # Fetch images for the current property
            productimage = ProductImage.objects.filter(product=products.id)

            # Check if there are any images for the property
            if productimage.exists():
                # Include only the first image in the combined data
                first = productimage.first()
                combineddata.append((products, first))
            else:
                # If no images are found, include the property data with None for the image
                combineddata.append((products, None))

        context= {"combineddata": combineddata}
        return render(request, "ecommerce-items.html", context)

    except:
        pass

    return render(request, "ecommerce-items.html")
