from django.db import models
from django.utils.safestring import mark_safe


# Create your models here.

class Login(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100, default="admin@123")
    phone_number = models.CharField(max_length=20, null=True, blank=True)
    userType = models.CharField(max_length=50, choices=(("user","user"),("store","store")), default="user")


    def __str__(self):
        return self.name


class State(models.Model):
    State_name = models.CharField(max_length=25)

    def __str__(self):
        return self.State_name


class City(models.Model):
    City_name = models.CharField(max_length=25)
    State_id = models.ForeignKey(State, on_delete=models.CASCADE)

    def __str__(self):
        return self.City_name


class Area(models.Model):
    Area_name = models.CharField(max_length=25)
    City_id = models.ForeignKey(City, on_delete=models.CASCADE)
    STATE = models.ForeignKey(State, on_delete=models.CASCADE)

    def __str__(self):
        return self.Area_name


class UserDetail(models.Model):
    userid = models.ForeignKey(Login, on_delete=models.CASCADE)
    dob = models.DateField()
    address = models.CharField(max_length=128)
    profile = models.ImageField(upload_to="photos", default="mydp.jpeg")
    area = models.ForeignKey(Area, on_delete=models.CASCADE)
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    state = models.ForeignKey(State, on_delete=models.CASCADE)

    def customer_photos(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.profile.url))

    customer_photos.allow_tags = True

    def __str__(self):
        return self.userid.name


class ProductCategory(models.Model):
    cateName = models.CharField(max_length=25)

    def __str__(self):
        return self.cateName


class Product(models.Model):
    name = models.CharField(max_length=25)
    Cate = models.ForeignKey(ProductCategory, on_delete=models.CASCADE, default="")
    desc = models.TextField()
    price = models.IntegerField()

    def __str__(self):
        return self.name



class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='product_images/', null=True, blank=True)

    def productPhoto(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.image.url))

    def __str__(self):
        return f"{self.product.name} - Image {self.id}"



class productCart(models.Model):
    user = models.ForeignKey(Login, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    Price = models.IntegerField(default=100)
    Quantity = models.IntegerField()
    Order_id = models.IntegerField(default=0)
    Order_status = models.IntegerField(default=0)
    timeStamp = models.DateTimeField(auto_now=True, editable=False)

    def __str__(self):
        return f"{self.user.name} - {self.product.name}"


class product_order(models.Model):
    totalAmount = models.IntegerField(default=0)
    user = models.ForeignKey(Login,on_delete=models.CASCADE)
    Address = models.TextField()
    order_status = models.CharField(max_length=50, choices=(('Pending', 'Pending'), ('Placed', 'Placed')))
    Payment_status = models.CharField(max_length=30)
    Date_time = models.DateTimeField(auto_now=True, editable=False)


class ecommercePayment(models.Model):
    user = models.ForeignKey(Login, on_delete=models.CASCADE)
    order_id = models.ForeignKey(product_order, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=50, choices=[('online', 'Online'), ('offline', 'Offline'),])
    transaction_id = models.CharField(max_length=255, blank=True, null=True)
    payment_status = models.CharField(max_length=30, choices=[('failed', 'Failed'),('pending', 'Pending'),('complete', 'Complete'),], default='pending')
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Payment - Order ID: {self.order_id}, User: {self.user.name}, Amount: {self.amount}, Status: {self.payment_status}"


class Store(models.Model):
    user = models.ForeignKey(Login, models.CASCADE)
    name = models.CharField(max_length=255)
    verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class StoreDetail(models.Model):
    store = models.ForeignKey(Store,on_delete=models.CASCADE)
    contact = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField()
    address = models.TextField(null=True, blank=True)
    logo = models.ImageField(upload_to='store_logos/', null=True, blank=True)
    description = models.TextField(null=True, blank=True)

    def storelogo(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.logo.url))

    def __str__(self):
        return self.store.name



class MachineCategory(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Machinery(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE)
    category = models.ForeignKey(MachineCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    available_for_rent = models.BooleanField(default=True)
    rental_duration = models.CharField(max_length=50, default='daily', choices=[('daily', 'Daily'), ('weekly', 'Weekly'), ('monthly', 'Monthly')])
    is_operational = models.BooleanField(default=True)
    production_year = models.PositiveIntegerField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class MachineryImage(models.Model):
    machinery = models.ForeignKey(Machinery, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='machinery_images/', null=True, blank=True)

    def machinePhoto(self):
        return mark_safe('<img src="{}" width="100"/>'.format(self.image.url))

    machinePhoto.allow_tags = True

    def __str__(self):
        return f"{self.machinery.name} - Image {self.id}"


class Booking(models.Model):
    user = models.ForeignKey(Login, on_delete=models.CASCADE)
    machinery = models.ForeignKey(Machinery, on_delete=models.CASCADE)
    date_booked = models.DateTimeField(auto_now_add=True)
    payment_method = models.CharField(max_length=50, choices=[('offline', 'Offline'),('online', 'Online')])
    status = models.CharField(max_length=50, default='pending', choices=[('pending', 'Pending'), ('confirmed', 'Confirmed')])
    start_date = models.DateField()
    end_date = models.DateField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)


    def __str__(self):
        return f"{self.user.name} - {self.machinery.name} - {self.date_booked}"



class payment(models.Model):
    user = models.ForeignKey(Login, on_delete=models.CASCADE)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)
    amount = models.IntegerField()
    transaction_id = models.CharField(max_length=255, blank=True, null=True)
    payment_date_time = models.DateTimeField(auto_now_add=True)
    payment_method = models.CharField(max_length=50, choices=[('offline', 'Offline'), ('online', 'Online')])
    payment_status = models.CharField(max_length=60, choices=[("failed","Failed"),("pending", "pending"), ("complete", "complete")], default= "pending")

    def __str__(self):
        return self.payment_status



class CardDetail(models.Model):
    name = models.CharField(max_length=50)
    card_number = models.CharField(max_length=50)
    card_cvv = models.CharField(max_length=50)
    exp_date = models.CharField(max_length=50)
    card_balance = models.IntegerField(default=1000000)

    def __str__(self):
        return self.card_number


class Feedback(models.Model):
    user = models.ForeignKey(Login, on_delete=models.CASCADE, default="")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    ratings = models.IntegerField()
    comment = models.CharField(max_length=300, default="")
    timestamp = models.DateTimeField(auto_now=True)

class Contact(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=11)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
